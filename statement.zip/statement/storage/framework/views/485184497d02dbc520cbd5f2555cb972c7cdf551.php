<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">

        <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>

        
    </head>
    <body>
        
         <div class="container">
            <div class="content">
                <form action="<?php echo url('enroll_college'); ?>" method="POST" class="form-inline">
                <?php echo csrf_field(); ?>

                  <label class="mr-sm-2" for="inlineFormCustomSelect">Company Name</label>
                  <select name="program_id" class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelect">
                    <option selected>Choose...</option>
                   <?php foreach($programs as $program): ?>
                    <option value="<?php echo $program->id; ?>"><?php echo $program->title; ?></option>
                   <?php endforeach; ?>
                  </select>
                  <br>
                  <select name="colleg_id" class="custom-select mb-2 mr-sm-2 mb-sm-0" id="inlineFormCustomSelect">
                    <option selected>Choose...</option>
                   <?php foreach($collegs as $colleg): ?>
                    <option value="<?php echo $colleg->id; ?>"><?php echo $colleg->title; ?></option>
                   <?php endforeach; ?>
                  </select>

                  <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            
        </div>

    </body>
</html>
