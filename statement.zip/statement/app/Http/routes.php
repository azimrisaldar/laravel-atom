<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/','KracksInController@dashboard');

Route::get('create_program',['as' => 'create-program','uses' => 'KracksInController@createProgram']);

Route::post('add_program','KracksInController@AddProgram');

Route::get('enroll_college',['as' => 'enroll_college','uses' => 'KracksInController@enrollCollege']);

Route::post('enroll_college','KracksInController@postEnrollCollege');

Route::post('genrate_report','KracksInController@genrateReport');