<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Company;

class HomeController extends Controller
{
    public function createProgram(){

    	$companies = Company::all();
    	
    	return view('create_program',compact('companies'));

    }
}
