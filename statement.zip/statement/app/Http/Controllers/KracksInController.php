<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Company;
use App\Program;
use App\College;

class KracksInController extends Controller
{
    
    
	public function dashboard(){

		$programs = College::all();

		return view('welcome',Compact('programs'));

	}

    public function createProgram(){

    	$companies = Company::all();
    	
    	return view('create_program',compact('companies'));

    }

    public function AddProgram(Request $request){

    	 Program::create($request->all());

		 return redirect()->route('create-program');	

    }

    public function enrollCollege(){

    	$programs = Program::all();
    	
    	$collegs  = College::all();

    	return view('enroll_college',Compact('programs','collegs'));

    }

    public function postEnrollCollege(Request $request){
    	
    	$college = College::whereId($request->colleg_id)->first();

    	$college->program()->attach($request->program_id);

    	return redirect()->route('enroll_college');	
    }

    public function genrateReport(Request $request){

    	$reports = College::whereId($request->college_id)->first();
        
        $collection = collect($reports->student->toArray());
        
        $male   = $collection->where('gender','male')->count();

        $female = $collection->where('gender','female')->count();
        
        $student_count = $collection->count();
        
    	return view('reports',compact('reports','male','female','student_count'));
    
    }




}
